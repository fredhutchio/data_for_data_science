# README for insulin vs control experiment

## Data dictionary
- date: month/day/year
- experiment: 1 through 4
- sex: M (male) or F (female)
- weight_g: weight in grams
- treatment: control or insulin
- calibrated: was scale calibrated appropriately?

## Data source

Data collected by Research Technican X in Professor Y's lab	
